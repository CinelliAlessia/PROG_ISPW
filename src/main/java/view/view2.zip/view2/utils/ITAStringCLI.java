package view.view2.utils;

public class ITAStringCLI {
    private ITAStringCLI(){}
    public static final String GENERES_FILE_PATH = "src/main/resources/musicGenres";

}
